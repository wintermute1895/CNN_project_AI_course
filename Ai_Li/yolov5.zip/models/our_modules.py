# 你可以将这段代码放在你项目的 custom_cnn_modules/attention_blocks.py 文件中
# 或者，为了在一周冲刺中简化导入路径问题，可以直接添加到 yolov5/models/common.py 的末尾，并清晰注释

import torch
import torch.nn as nn

class SEBlock(nn.Module):
    """
    Squeeze-and-Excitation Block.
    A channel-wise attention mechanism that adaptively recalibrates channel-wise feature responses.
    """
    def __init__(self, c1, r=16):  # c1: input channels, r: reduction ratio
        super(SEBlock, self).__init__()
        if c1 <= r: # Ensure c1 // r is at least 1, or handle small c1 cases
            r = c1 // 2 if c1 > 1 else c1 # Adjust r if c1 is too small
            if r == 0: r = 1 # Avoid division by zero or zero channels

        self.squeeze = nn.AdaptiveAvgPool2d(1)  # Global Average Pooling
        self.excitation = nn.Sequential(
            nn.Conv2d(c1, c1 // r, kernel_size=1, stride=1, padding=0, bias=False), # 1x1 Conv to reduce channels
            nn.SiLU(),  # Activation function (YOLOv5 often uses SiLU)
            nn.Conv2d(c1 // r, c1, kernel_size=1, stride=1, padding=0, bias=False), # 1x1 Conv to restore channels
            nn.Sigmoid()  # Sigmoid to get channel-wise weights between 0 and 1
        )

    def forward(self, x):
        """
        x: input tensor of shape (batch_size, channels, height, width)
        """
        b, c, _, _ = x.size()
        weights = self.excitation(self.squeeze(x)) # Squeeze and Excitation
                                                    # squeeze(x) -> (b, c, 1, 1)
                                                    # excitation(...) -> (b, c, 1, 1)
        return x * weights # Scale original features by a_project_AI_course/.git/.MERGE_MSG.swp"
    to recover the changes (see ":help recovery").
    If you did this already, delete the swap file "/f/Anaconda/envs/pytorch/CNN_project_AI_course/.git/.MERGE_MSG.swp"
    to avoid this message.
Swap file "/f/Anaconda/envs/pytorch/CNN_project_AI_course/.git/.MERGE_MSG.swp" already exists!
[O]pen Read-Only, (E)dit anyway, (R)ecover, (D)elete it, (Q)uit, (A)bort:
Swap file "/f/Anaconda/envs/pytorch/CNN_project_AI_course/.git/.MERGE_MSG.swp" already exists!
[O]pen Read-Only, (E)dit anyway, (R)ecover, (D)elete it, (Q)uit, (A)bort: